import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Users, ChevronLeft, ChevronRight } from 'lucide-react';

const FacilitySlider = () => {
  const facilities = [
    {
      slug: 'miyakojima',
      name: 'G・MOTO都島本通り',
      type: 'リハビリ特化型デイサービス',
      address: '大阪市都島区本通4-15-8',
      capacity: '定員25名',
      image: 'https://images.pexels.com/photos/6111694/pexels-photo-6111694.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop'
    },
    {
      slug: 'hirakata',
      name: 'G・MOTO枚方',
      type: 'リハビリ特化型デイサービス',
      address: '枚方市○○町1-2-3',
      capacity: '定員20名',
      image: 'https://images.pexels.com/photos/7551659/pexels-photo-7551659.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop'
    },
    {
      slug: 'tondabayashi',
      name: 'G・MOTO富田林',
      type: 'リハビリ特化型デイサービス',
      address: '富田林市○○町4-5-6',
      capacity: '定員18名',
      image: 'https://images.pexels.com/photos/263402/pexels-photo-263402.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop'
    },
    {
      slug: 'gofuku',
      name: 'リハビス呉服',
      type: '介護予防フィットネス',
      address: '大阪市○○区呉服町7-8-9',
      capacity: '定員15名',
      image: 'https://images.pexels.com/photos/6111477/pexels-photo-6111477.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop'
    },
    {
      slug: 'ikeda',
      name: 'ケアプラン池田',
      type: 'ケアプランセンター',
      address: '池田市○○町10-11-12',
      capacity: 'ケアマネ5名',
      image: 'https://images.pexels.com/photos/8865994/pexels-photo-8865994.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop'
    }
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const itemsPerPage = 3;

  const nextSlide = () => {
    setCurrentIndex((prev) => 
      prev + itemsPerPage >= facilities.length ? 0 : prev + itemsPerPage
    );
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => 
      prev === 0 ? Math.max(0, facilities.length - itemsPerPage) : prev - itemsPerPage
    );
  };

  const visibleFacilities = facilities.slice(currentIndex, currentIndex + itemsPerPage);

  return (
    <div className="relative">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {visibleFacilities.map((facility) => (
          <div key={facility.slug} className="bg-white rounded-xl shadow-soft overflow-hidden hover:shadow-soft-lg transition-shadow">
            <div className="relative h-48">
              <img
                src={facility.image}
                alt={facility.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 left-4">
                <span className="bg-primary text-white px-3 py-1 rounded-full text-sm font-medium">
                  {facility.type}
                </span>
              </div>
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-2">{facility.name}</h3>
              <div className="space-y-2 mb-4">
                <div className="flex items-center text-gray-600">
                  <MapPin className="w-4 h-4 mr-2" />
                  <span className="text-sm">{facility.address}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Users className="w-4 h-4 mr-2" />
                  <span className="text-sm">{facility.capacity}</span>
                </div>
              </div>
              <Link
                to={`/facilities/${facility.slug}`}
                className="inline-block w-full text-center bg-primary text-white py-2 rounded-lg font-medium hover:bg-primary-hover transition-colors"
              >
                詳細を見る
              </Link>
            </div>
          </div>
        ))}
      </div>

      {facilities.length > itemsPerPage && (
        <div className="flex justify-center mt-8 space-x-4">
          <button
            onClick={prevSlide}
            className="p-2 rounded-full bg-white border border-gray-300 hover:bg-gray-50 transition-colors"
          >
            <ChevronLeft className="w-6 h-6 text-gray-600" />
          </button>
          <button
            onClick={nextSlide}
            className="p-2 rounded-full bg-white border border-gray-300 hover:bg-gray-50 transition-colors"
          >
            <ChevronRight className="w-6 h-6 text-gray-600" />
          </button>
        </div>
      )}
    </div>
  );
};

export default FacilitySlider;