import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Users, Calendar, ArrowRight, Clock, Target, Star } from 'lucide-react';

const Services = () => {
  const dayServiceFeatures = [
    {
      icon: Heart,
      title: '機能訓練',
      description: '理学療法士による個別リハビリプログラム'
    },
    {
      icon: Users,
      title: '口腔体操',
      description: '言語聴覚士指導による嚥下機能向上'
    },
    {
      icon: Clock,
      title: '入浴・食事',
      description: '安全で快適な日常生活動作の支援'
    }
  ];

  const fitnessFeatures = [
    {
      icon: Target,
      title: '介護予防',
      description: '要支援状態の改善・維持を目指したプログラム'
    },
    {
      icon: Star,
      title: '認知症予防',
      description: '脳トレーニングと運動の組み合わせ'
    },
    {
      icon: Users,
      title: '楽しい運動',
      description: 'グループでの楽しいフィットネス活動'
    }
  ];

  const careplanFeatures = [
    {
      icon: Users,
      title: 'ケアマネ支援',
      description: '経験豊富なケアマネジャーによる個別相談'
    },
    {
      icon: Calendar,
      title: 'サービス調整',
      description: '最適なケアプランの作成と調整'
    },
    {
      icon: Heart,
      title: '総合支援',
      description: 'ご利用者様とご家族の暮らしをトータルサポート'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-primary to-accent py-16">
        <div className="max-w-8xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">事業紹介</h1>
            <p className="text-xl opacity-90 max-w-2xl mx-auto">
              三位一体のサービスで<br />
              ご利用者様の自立支援をサポートします
            </p>
          </div>
        </div>
      </section>

      {/* Day Service Section */}
      <section id="dayservice" className="py-16">
        <div className="max-w-8xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">リハビリ特化型デイサービス</h2>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-8">
                理学療法士・作業療法士・言語聴覚士などの専門スタッフが、
                一人ひとりの状態に合わせたリハビリプログラムを提供します。
                機能訓練から日常生活動作の向上まで、総合的にサポートいたします。
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
                {dayServiceFeatures.map((feature, index) => (
                  <div key={index} className="text-center">
                    <div className="w-16 h-16 bg-accent rounded-lg flex items-center justify-center mx-auto mb-4">
                      <feature.icon className="w-8 h-8 text-primary" />
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2">{feature.title}</h3>
                    <p className="text-sm text-gray-600">{feature.description}</p>
                  </div>
                ))}
              </div>
              <Link
                to="/facilities"
                className="inline-flex items-center bg-primary text-white px-6 py-3 rounded-lg font-semibold hover:bg-primary-hover transition-colors"
              >
                該当施設を見る
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
              <Link
                to="/services/rehabilitation-dayservice"
                className="inline-flex items-center border border-primary text-primary px-6 py-3 rounded-lg font-semibold hover:bg-primary hover:text-white transition-colors ml-4"
              >
                詳しく見る
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/6111694/pexels-photo-6111694.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop"
                alt="リハビリ特化型デイサービス"
                className="w-full h-96 object-cover rounded-xl shadow-soft-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Fitness Section */}
      <section id="fitness" className="py-16 bg-gray-50">
        <div className="max-w-8xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <img
                src="https://images.pexels.com/photos/7551659/pexels-photo-7551659.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop"
                alt="介護予防フィットネス"
                className="w-full h-96 object-cover rounded-xl shadow-soft-lg"
              />
            </div>
            <div className="order-1 lg:order-2">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">介護予防フィットネス</h2>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-8">
                要支援の方を対象とした介護予防に特化したフィットネスプログラムです。
                楽しみながら身体機能の維持・向上を図り、認知症予防にも効果的な
                運動メニューを豊富にご用意しています。
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
                {fitnessFeatures.map((feature, index) => (
                  <div key={index} className="text-center">
                    <div className="w-16 h-16 bg-accent rounded-lg flex items-center justify-center mx-auto mb-4">
                      <feature.icon className="w-8 h-8 text-primary" />
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2">{feature.title}</h3>
                    <p className="text-sm text-gray-600">{feature.description}</p>
                  </div>
                ))}
              </div>
              <Link
                to="/facilities/gofuku"
                className="inline-flex items-center bg-primary text-white px-6 py-3 rounded-lg font-semibold hover:bg-primary-hover transition-colors"
              >
                リハビス呉服を見る
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Care Plan Section */}
      <section id="careplan" className="py-16">
        <div className="max-w-8xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">ケアプランセンター</h2>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-8">
                経験豊富なケアマネジャーが、ご利用者様一人ひとりの状況に合わせて
                最適なケアプランを作成します。介護サービスの調整から
                ご家族へのサポートまで、トータルでお手伝いいたします。
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
                {careplanFeatures.map((feature, index) => (
                  <div key={index} className="text-center">
                    <div className="w-16 h-16 bg-accent rounded-lg flex items-center justify-center mx-auto mb-4">
                      <feature.icon className="w-8 h-8 text-primary" />
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2">{feature.title}</h3>
                    <p className="text-sm text-gray-600">{feature.description}</p>
                  </div>
                ))}
              </div>
              <Link
                to="/facilities/ikeda"
                className="inline-flex items-center bg-primary text-white px-6 py-3 rounded-lg font-semibold hover:bg-primary-hover transition-colors"
              >
                ケアプラン池田を見る
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/8865994/pexels-photo-8865994.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop"
                alt="ケアプランセンター"
                className="w-full h-96 object-cover rounded-xl shadow-soft-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            サービスについてもっと詳しく知りたい方へ
          </h2>
          <p className="text-xl text-white mb-8 opacity-90">
            各施設の詳細情報や見学のご予約はこちらから
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/facilities"
              className="bg-white text-primary px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors shadow-lg"
            >
              施設一覧を見る
            </Link>
            <Link
              to="/contact"
              className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-primary transition-colors"
            >
              お問い合わせ
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;